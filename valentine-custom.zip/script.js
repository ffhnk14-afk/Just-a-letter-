function showLove() {
    let text = document.getElementById("text");
    text.innerHTML = `Welcome home sayang… sowryyy tadi mau nulis surat tidak sempattt hehe.
Kalo kamu nanya kenapa ada bunga? Jawaban nya ya gapapa aku pengen aja.
Walaupun ngasih bunga identik ke cowo yg ngasih ke cewe, tapi menurut ku engga sih,
cowo juga boleh dikasih. Bunga itu bisa menyimbolkan rasa sayang, cinta, perhatian, dll nya..
so, kamu juga boleh dapet itu kan dari aku wkwkwk.
Yaudah gitu aja, loveyouu❤️`;
    text.style.textShadow = "0 0 20px #fff, 0 0 40px #ff1493";
    text.style.transform = "scale(1.05)";
    text.style.transition = "0.3s";
}
